import java.util.ArrayList;
import java.util.List;

/**
 * Class that represent a film studio
 */
//Class to represent to a film studio
public class FilmStudio {
    //some fields to use the methods
    /**
     * Constructs a FilmStudio object with the given name.
     */
    private final String name;
    private final List<Film> films;

    //Construct method
    public FilmStudio(String name) {
        this.name = name;
        this.films = new ArrayList<>();
    }

    //add film to a film studio
    public void addFilm(Film film) {
        films.add(film);
    }

    //Getter methods
    public String getName() {
        return name;
    }

    public List<Film> getFilms() {
        return films;
    }

    /**
     * Retrieves the longest film produced by the film studio.
     *
     * @return The longest film produced by the film studio.
     */
    public Film getLongestFilm() {
        Film longestFilm = null;
        int maxlength = 0;
        for (Film film : films) {
            if (film.getRunTime() > maxlength) {
                maxlength = film.getRunTime();
                longestFilm = film;
            }
        }
        return longestFilm;
    }

    /**
     * Calculates the average box office earnings of films
     *
     * @return The average box office earnings of films produced by the film studio
     */
    public double getAverageBoxOfficeEarnings(int year) {
        int totalEarnings = 0;
        int filmCount = 0;
        for (Film film : films) {
            if (film.getYearOfRelease() == year) {
                totalEarnings += (int) film.getBoxOfficeEarnings();
                filmCount++;
            }
        }
        if (filmCount == 0) {
            return 0; // Avoid division by zero
        }
        return (double) totalEarnings / filmCount;
    }

    /**
     * The films with box office earning less than threshold
     */
    public List<Film> getFilmsWithEarningsLessThan(int earningsThreshold) {
        List<Film> filmsWithLessEarnings = new ArrayList<>();
        for (Film film : films) {
            if (film.getBoxOfficeEarnings() < earningsThreshold) {
                filmsWithLessEarnings.add(film);
            }
        }
        return filmsWithLessEarnings;
    }

    /**
     * Displays information about the film studio and its produced films.
     */
    //display information about the film studios and films
    public void displayInfo() {
        System.out.println("Film Studio: " + name);
        System.out.println("Films produced:");
        for (Film film : films) {
            System.out.println("- " + film.getTitle());
        }
    }

    /**
     * Test method to demonstrate the functionality of the FilmStudio class.
     *
     * @param args the command-line arguments
     */
    //some test methods
    public static void main(String[] args) {
        // Example usage
        FilmStudio studio = new FilmStudio("Example Studio");
        studio.addFilm(new Film("Harry Potter", 2020, 120, 1000000, Genre.ACTION));
        studio.addFilm(new Film("The Abyss", 2021, 110, 2000000, Genre.COMEDY));
        studio.addFilm(new Film("Dune", 2022, 130, 1500000, Genre.HORROR));
        studio.displayInfo();

        // Attempt to calculate average earnings for a year with negative year
        System.out.println("Attempting to calculate average box office earnings for a negative year...");
        double averageEarningsNegativeYear = studio.getAverageBoxOfficeEarnings(-2020);
        System.out.println("Average box office earnings in -2020: " + averageEarningsNegativeYear);
        System.out.println();

        // Attempt to retrieve films with earnings less than threshold where threshold is negative
        System.out.println("Attempting to retrieve films with earnings less than negative threshold...");
        List<Film> lowEarningFilmsNegativeThreshold = studio.getFilmsWithEarningsLessThan(-1500000);
        if (lowEarningFilmsNegativeThreshold.isEmpty()) {
            System.out.println("Error: Threshold cannot be negative.");
        }
        System.out.println();
    }
}

