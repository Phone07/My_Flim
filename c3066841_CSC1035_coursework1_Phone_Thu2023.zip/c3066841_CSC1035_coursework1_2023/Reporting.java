import java.util.ArrayList;
import java.util.List;

/**
 * Class for Reporting
 */
//class for reporting
public class Reporting {
    private final List<FilmStudio> filmStudios;

    /**
     * Constructs a Reporting object.
     */
    public Reporting() {
        filmStudios = new ArrayList<>();
    }

    /**
     * Adds a film studio to the list of film studios.
     *
     * @param studio The film studio to add.
     */
    // Method to add a film studio to the list
    public void addFilmStudio(FilmStudio studio) {
        filmStudios.add(studio);
    }

    /**
     * Retrieves the list of film studios.
     *
     * @return The list of film studios.
     */
    //Getter methods for film studios, longest film and largest average earnings
    public List<FilmStudio> getFilmStudios() {
        return filmStudios;
    }

    /**
     * Retrieves the longest film ever made among all film studios.
     *
     * @return The longest film ever made.
     */
    public Film getLongestFilmEverMade() {
        Film longestFilm = null;
        int maxLength = 0;
        for (FilmStudio studio : filmStudios) {
            Film film = studio.getLongestFilm();
            if (film != null && film.getLengthInMinutes() > maxLength) {
                maxLength = film.getLengthInMinutes();
                longestFilm = film;
            }
        }
        return longestFilm;
    }

    /**
     * The film studio with the largest average earnings in a given year.
     *
     * @param year The year to find the studio with the largest average earnings.
     * @return The film studio with the largest average earnings in the given year.
     */
    public FilmStudio getStudioWithLargestAverageEarnings(int year) {
        FilmStudio largestEarningStudio = null;
        double maxAverageEarnings = 0;
        for (FilmStudio studio : filmStudios) {
            double averageEarnings = studio.getAverageBoxOfficeEarnings(year);
            if (averageEarnings > maxAverageEarnings) {
                maxAverageEarnings = averageEarnings;
                largestEarningStudio = studio;
            }
        }
        return largestEarningStudio;
    }

    /**
     * A list of films with earnings less than a specified threshold from all film studios.
     *
     * @param earningsThreshold The threshold for earnings.
     * @return A list of films with earnings less than the specified threshold.
     */
    //Method to get films with earnings less than a specified threshold
    public List<Film> getFilmsWithEarningsLessThan(int earningsThreshold) {
        if (earningsThreshold <= 0) {
            throw new IllegalArgumentException("Earnings threshold must be greater than zero.");
        }

        List<Film> filmsWithLessEarnings = new ArrayList<>();
        for (FilmStudio studio : filmStudios) {
            filmsWithLessEarnings.addAll(studio.getFilmsWithEarningsLessThan(earningsThreshold));
        }
        return filmsWithLessEarnings;
    }


    /**
     * Test methods to demonstrate the function for the reporting class
     *
     * @param args the command-line arguments
     */
    //some test statements
    public static void main(String[] args) {
        // Create some film studios
        FilmStudio studio1 = new FilmStudio("Leavesden");
        FilmStudio studio2 = new FilmStudio("Disney");
        FilmStudio studio3 = new FilmStudio("Legendary Pictures Villeneuve Films");

        // Add films to studios
        studio1.addFilm(new Film("Harry Potter", 2020, 120, 1000000, Genre.ACTION));
        studio1.addFilm(new Film("The Abyss", 2021, 110, 2000000, Genre.COMEDY));
        studio2.addFilm(new Film("Dune", 2022, 130, 1500000, Genre.HORROR));

        // Create a reporting object and add studios
        Reporting reporting = new Reporting();
        reporting.addFilmStudio(studio1);
        reporting.addFilmStudio(studio2);

        // Test getLongestFilmEverMade method
        Film longestFilm = reporting.getLongestFilmEverMade();
        if (longestFilm != null) {
            System.out.println("Longest Film Ever Made: " + longestFilm.getTitle());
        } else {
            System.out.println("No films found among the studios.");
        }

        // Test getStudioWithLargestAverageEarnings method
        int year = 2021;
        FilmStudio largestEarningStudio = reporting.getStudioWithLargestAverageEarnings(year);
        if (largestEarningStudio != null) {
            System.out.println("Studio with Largest Average Earnings in " + year + ": " + largestEarningStudio.getName());
        } else {
            System.out.println("No studios found with earnings information for the year " + year);
        }

        // Test getFilmsWithEarningsLessThan method with invalid earningsThreshold
        int invalidEarningsThreshold = 0;
        try {
            List<Film> filmsWithLessEarnings = reporting.getFilmsWithEarningsLessThan(invalidEarningsThreshold);
            System.out.println("Films with earnings less than £" + invalidEarningsThreshold + ":");
            for (Film film : filmsWithLessEarnings) {
                System.out.println("- " + film.getTitle());
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

