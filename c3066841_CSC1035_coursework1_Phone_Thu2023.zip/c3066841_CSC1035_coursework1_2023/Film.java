/**
 * An enum for different genres of films
 */
//An enum for different genres of films
enum Genre {
    COMEDY,
    HORROR,
    ACTION,

}

/**
 * A class to represent a film
 */
//A class to represent a film
public class Film {
    //Private fields to store film details
    private String title;
    private int yearOfRelease;
    private int lengthInMinutes;
    private double boxOfficeEarnings;
    private Genre genre;

    //Construct to initialize film details
    public Film(String title, int yearOfRelease, int lengthInMinutes,
                double boxOfficeEarnings, Genre genre) {
        this.title = title;
        this.yearOfRelease = yearOfRelease;
        this.lengthInMinutes = lengthInMinutes;
        this.boxOfficeEarnings = boxOfficeEarnings;
        this.genre = genre;
    }

    /**
     * Gets the title of the film
     *
     * @return the title of the film
     */
    //Getter methods to access the film details
    public String getTitle() {
        return title;
    }

    /**
     * Gets the year of release of the film.
     *
     * @return The year of release of the film.
     */
    public int getYearOfRelease() {
        return yearOfRelease;
    }

    /**
     * Gets the length of the film in minutes.
     *
     * @return The length of the film in minutes.
     */
    public int getLengthInMinutes() {
        return lengthInMinutes;
    }

    /**
     * Gets the box office earnings of the film.
     *
     * @return The box office earnings of the film.
     */
    public double getBoxOfficeEarnings() {
        return boxOfficeEarnings;
    }

    /**
     * Gets the genre of the film.
     *
     * @return The genre of the film.
     */
    public Genre getGenre() {
        return genre;
    }

    /**
     * Sets the title of the film.
     *
     * @param title The new title of the film.
     */
    //Setter methods to modify film details
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Sets the year of release of the film.
     *
     * @param yearOfRelease The new year of release of the film.
     * @throws IllegalArgumentException if the year of release is zero or negative.
     */
    public void setYearOfRelease(int yearOfRelease) {
        if (yearOfRelease <= 0) {
            throw new IllegalArgumentException("Year of release cannot be zero or negative.");
        }
        this.yearOfRelease = yearOfRelease;
    }

    /**
     * Sets the length of the film in minutes.
     *
     * @param lengthInMinutes The new length of the film in minutes.
     * @throws IllegalArgumentException if the length in minutes is zero or negative.
     */
    public void setLengthInMinutes(int lengthInMinutes) {
        if (lengthInMinutes <= 0) {
            throw new IllegalArgumentException("Length in minutes cannot be zero or negative.");
        }
        this.lengthInMinutes = lengthInMinutes;
    }

    /**
     * Sets the box office earnings of the film.
     *
     * @param boxOfficeEarnings The new box office earnings of the film.
     * @throws IllegalArgumentException if the box office earnings are negative.
     */
    public void setBoxOfficeEarnings(double boxOfficeEarnings) {
        if (boxOfficeEarnings < 0) {
            throw new IllegalArgumentException("Box office earnings cannot be negative.");
        }
        this.boxOfficeEarnings = boxOfficeEarnings;
    }

    /**
     * Sets the genre of the film.
     *
     * @param genre The new genre of the film.
     */
    public void setGenre(Genre genre) {
        this.genre = genre;
    }

    /**
     * Gets the runtime of the film.
     *
     * @return The runtime of the film.
     */
    //Get Runtime for a film
    public int getRunTime() {
        return lengthInMinutes;
    }

    /**
     * Returns a string representation of the film.
     *
     * @return A string representation of the film.
     */
    //method to return film details as a String
    public String toString() {
        return "Film{" +
                "title='" + title + '\'' +
                ", yearOfRelease=" + yearOfRelease +
                ", lengthInMinutes=" + lengthInMinutes +
                ", boxOfficeEarnings=" + boxOfficeEarnings +
                ", genre='" + genre + '\'' +
                '}';
    }

    //Some test statements
    public static void main(String[] args) {
        // Creating instances of films
        Film film1 = new Film("Harry Potter and the Half-Blood Prince", 1994, 142, 28.34, Genre.HORROR);
        Film film2 = new Film("The Abyss", 2008, 152, 1.005, Genre.ACTION);

        // Printing film details
        System.out.println("Film 1:");
        System.out.println(film1);
        System.out.println();

        System.out.println("Film 2:");
        System.out.println(film2);
        System.out.println();

        // Testing getters and setters
        System.out.println("Film 1's title before modification: " + film1.getTitle());
        film1.setTitle("Harry Potter");
        System.out.println("Film 1's title after modification: " + film1.getTitle());
        System.out.println();

        System.out.println("Film 2's year of release before modification: " + film2.getYearOfRelease());
        film2.setYearOfRelease(2009);
        System.out.println("Film 2's year of release after modification: " + film2.getYearOfRelease());
        System.out.println();

        // Testing invalid modification
        try {
            // Attempting to set negative year of release
            System.out.println("Attempting to set negative year of release for Film 1...");
            film1.setYearOfRelease(-2000);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println();

        try {
            // Attempting to set zero length in minutes
            System.out.println("Attempting to set zero length in minutes for Film 2...");
            film2.setLengthInMinutes(0);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println();

        try {
            // Attempting to set negative box office earnings
            System.out.println("Attempting to set negative box office earnings for Film 1...");
            film1.setBoxOfficeEarnings(-30.0);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println();
    }
}
