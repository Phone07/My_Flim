import java.util.List;
import java.util.Scanner;
/**
 * Class for handling user inputs and providing a menu interface for reporting on film studios and their films.
 */
//Class for user inputs
public class ReportingIO {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Reporting reporting = new Reporting();

    /**
     * Main method for running the program and displaying the menu interface.
     *
     * @param args The command-line arguments.
     */
    //Main methods for running program
    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            //Display menu with options
            System.out.println("Menu");
            System.out.println("1. Enter the film studio");
            System.out.println("2. Enter film data");
            System.out.println("3. Enter list all film studios");
            System.out.println("4. List all films given film studio");
            System.out.println("5. Reporting Statistics");
            System.out.println("6. Exit");
            System.out.println("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            //giving user options with switch case
            switch (choice) {
                case 1:
                    enterFilmStudioData();
                    break;
                case 2:
                    enterFilmData();
                    break;
                case 3:
                    listAllFilmStudios();
                    break;
                case 4:
                    listFilmsByFilmStudio();
                    break;
                case 5:
                    runReportingStatistics();
                    break;
                case 6:
                    exit = true;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please choose again.");
                    break;
            }
        }
    }
    /**
     * Method to enter film studio data.
     */
    //method to enter film studio data
    private static void enterFilmStudioData() {
        System.out.print("Enter film studio name: ");
        String name = scanner.nextLine();
        FilmStudio studio = new FilmStudio(name);
        reporting.addFilmStudio(studio);
        System.out.println("Film studio added successfully.");
    }
    /**
     * Method to enter film data.
     */
    //method for film data
    private static void enterFilmData() {
        System.out.print("Enter film studio name: ");
        String studioName = scanner.nextLine();
        FilmStudio studio = findFilmStudio(studioName);
        if (studio != null) {
            System.out.print("Enter film title: ");
            String title = scanner.nextLine();
            System.out.print("Enter year of release: ");
            int year = scanner.nextInt();
            System.out.print("Enter length in minutes: ");
            int length = scanner.nextInt();
            System.out.print("Enter box office earnings: ");
            double earnings = scanner.nextDouble();
            System.out.print("Enter genre (COMEDY, HORROR, ACTION): ");
            Genre genre = Genre.valueOf(scanner.next().toUpperCase());

            studio.addFilm(new Film(title, year, length, earnings, genre));
            System.out.println("Film added successfully.");
        } else {
            System.out.println("Film studio not found.");
        }
    }
    /**
     * Method to list all film studios.
     */
    //method to list all film studios
    private static void listAllFilmStudios() {
        System.out.println("List of all film studios:");
        List<FilmStudio> studios = reporting.getFilmStudios();
        for (FilmStudio studio: studios) {
            System.out.println("- " + studio.getName());
        }
    }
    /**
     * Method to list all films by a specific film studio.
     */
    private static void listFilmsByFilmStudio() {
        System.out.print("Enter film studio name: ");
        String studioName = scanner.nextLine();
        FilmStudio studio = findFilmStudio(studioName);
        if (studio != null) {
            System.out.println("Films made by " + studioName + ":");
            for (Film film : studio.getFilms()) {
                System.out.println("- " + film.getTitle());
            }
        } else {
            System.out.println("Film studio not found.");
        }
    }
    /**
     * Method to run reporting statistics.
     */
    //method to run reporting statistics
    private static void runReportingStatistics() {
        System.out.print("Enter the year for average earnings calculation: ");
        int year = scanner.nextInt();
        FilmStudio studioWithLargestAverageEarnings = reporting.getStudioWithLargestAverageEarnings(year);
        if (studioWithLargestAverageEarnings != null) {
            System.out.println("Studio with largest average earnings in " + year + ": " + studioWithLargestAverageEarnings.getName());
        } else {
            System.out.println("No studio found for the given year.");
        }

        Film longestFilm = reporting.getLongestFilmEverMade();
        System.out.println("Longest film ever made: " + longestFilm.getTitle() + " (" + longestFilm.getLengthInMinutes() + " minutes)");

        System.out.print("Enter earnings threshold: ");
        double earningsThreshold = scanner.nextDouble();
        List<Film> filmsWithLessEarnings = reporting.getFilmsWithEarningsLessThan((int) earningsThreshold);
        System.out.println("Films with earnings less than £" + earningsThreshold + ":");
        for (Film film : filmsWithLessEarnings) {
            System.out.println("- " + film.getTitle() + " (" + film.getBoxOfficeEarnings() + ")");
        }
    }

    /**
     * Method to find a film studio by name
     * @param name The name of the film studio to find
     * @return The film studio object is found or not found
     */
    //Method to find a film studio by name and return film studios if the program found
    private static FilmStudio findFilmStudio(String name) {
        List<FilmStudio> studios = reporting.getFilmStudios();
        for (FilmStudio studio : studios) {
            if (studio.getName().equalsIgnoreCase(name)) {
                return studio;
            }
        }
        return null;
    }
}
